package chp6;

public class TweetVO {
	private String tweet;
	private double label;
	
	public TweetVO() {
		
	}

	public String getTweet() {
		return tweet;
	}

	public void setTweet(String tweet) {
		this.tweet = tweet;
	}

	public double getLabel() {
		return label;
	}

	public void setLabel(double label) {
		this.label = label;
	}


	
	
}
