This project contains the code for Chp 3 on Data Visualization on Big data.

It contains the code for all the charts build using JFreeChart and Apache Spark.
