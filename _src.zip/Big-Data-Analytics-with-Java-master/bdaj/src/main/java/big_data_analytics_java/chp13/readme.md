This chapter has its code in its own java project.

Please check the project bdaj_deeplearning_chp13