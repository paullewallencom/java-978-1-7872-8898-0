# Big Data Analytics with Java - Chp 11

# This java package contains code about the
  chapter 11 on Graph Analytics on Big Data