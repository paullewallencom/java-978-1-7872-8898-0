package big_data_analytics_java.chp2;

/*
 * Market Basket Analysis
 * 
 * 
 */
public class MarketBasketAnalysis {

	public static void main(String[] args) {

	}

}
