package big_data_analytics_java.chp1;

public class Test {

	public static void main(String[] args) {
		System.out.println("Car type -> Abarth");
		System.out.println("Car type -> AlfaRomeo");
		System.out.println("Car type -> Autobianchi");
		System.out.println("Car type -> Bizzarinni");
		System.out.println("Car type -> Bugatti");
	}

}
