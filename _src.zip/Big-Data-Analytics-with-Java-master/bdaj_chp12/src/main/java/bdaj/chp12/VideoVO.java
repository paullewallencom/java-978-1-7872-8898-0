package bdaj.chp12;

public class VideoVO {
private String videoID;
private int videoCount;

public VideoVO() {
	
}

public String getVideoID() {
	return videoID;
}

public void setVideoID(String videoID) {
	this.videoID = videoID;
}

public int getVideoCount() {
	return videoCount;
}

public void setVideoCount(int videoCount) {
	this.videoCount = videoCount;
}


}
