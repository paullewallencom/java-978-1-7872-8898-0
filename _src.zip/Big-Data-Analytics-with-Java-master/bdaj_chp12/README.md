# Big Data Analytics with Java - Chp 12

# Using Spark Streaming with Apache Kafka 

An example project that shows how to use Spark Streaming 1.6.2 with Kafka as input and the Confluent Schema Registry using a specific Avro record (not the generic record).

This was tested against Kafka 0.10.0.0.

This is the _master_ branch. The 
_spark-2_ branch contains a version that is using Spark 2.0.0.
